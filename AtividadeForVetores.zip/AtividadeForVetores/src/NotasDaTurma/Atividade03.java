package NotasDaTurma;

import java.util.Scanner;

public class Atividade03 {
    static void main() {
        Scanner sc = new Scanner(System.in);
        int aprovados = 0;
        int reprovados = 0;

        double[] nota = new double[10];
        for (int i = 0; i < 10; i++) {
            System.out.println("Informe a nota do aluno " + (i + 1) + ":");
            nota[i] = sc.nextDouble();
        }
        for (int i = 0; i < 10; i++) {
            if (nota[i] >= 6) {
                aprovados++;
            } else {
                reprovados++;
            }
        }

        System.out.print(+aprovados + "  Alunos Aprovados e ");
        System.out.print(+reprovados + "  Alunos Reprovados");
    }

    }




