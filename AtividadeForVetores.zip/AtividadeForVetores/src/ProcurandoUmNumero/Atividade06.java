package ProcurandoUmNumero;

import java.util.Scanner;

public class Atividade06 {
    static void main() {
        Scanner sc = new Scanner(System.in);

        int[] vetor = new int[10];

        for (int i = 0; i < 10; i++) {
            System.out.print("Digite o " + (i + 1) + "º número: ");
            vetor[i] = sc.nextInt();
        }

        System.out.print("Qual número deseja procurar? ");
        int busca = sc.nextInt();

        boolean encontrado = false;

        for (int i = 0; i < 10; i++) {
            if (vetor[i] == busca) {
                System.out.println("Número encontrado na posição " + i++ + ".");
                encontrado = true;
            }
        }

        if (encontrado) {
            System.out.println("Número não encontrado.");
        }


    }
}





