
import java.util.Scanner;

public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    double soma = 0;


    int[] temperaturas = new int[7];
    for (int i = 0; i < 7; i++) {
        System.out.print("Informe a temperatura do dia " + (i + 1) + ": ");
        temperaturas[i] = sc.nextInt();

        soma += temperaturas[i];
    }

    System.out.println(" Temperatura dos dias da semana : ");

    for (int i = 0; i < 7; i++) {
        System.out.println(" Temperatura do dia " + (i + 1) + " : " + temperaturas[i] + " ºC");
    }
    double media = soma / 7;

    System.out.printf("Media da semana: " + media + " ºC ");
}