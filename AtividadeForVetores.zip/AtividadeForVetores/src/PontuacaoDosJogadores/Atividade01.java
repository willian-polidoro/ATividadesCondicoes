
import java.util.Scanner;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        int[] pontuacao = new int[5];
        for (int i = 0; i < 5; i++) {
            System.out.print("Informe a pontução do jogador " + (i + 1) + ": ");
            pontuacao[i] = sc .nextInt();
        }

        System.out.println(" Pontuações cadastradas : ");

        for (int i = 0; i < 5; i++) {
            System.out.println("Jogador " + (i + 1) + " : " + pontuacao[i] + " pontos");
        }
    }
