package RankingDosJogadores;

import java.util.Scanner;

public class Atividade08 {
    static void main() {

        Scanner sc = new Scanner(System.in);

        String[] nomes = new String[5];
        int[] pontos = new int[5];

        for (int i = 0; i < 5; i++) {
            System.out.print("Digite o nome do jogador " + (i + 1) + ": ");
            nomes[i] = sc.nextLine();

            System.out.print("Digite a pontuação: ");
            pontos[i] = sc.nextInt();
            sc.nextLine();
        }

        int maiorPontuacao = pontos[0];
        int posicaoCampeao = 0;

        for (int i = 1; i < 5; i++) {
            if (pontos[i] > maiorPontuacao) {
                maiorPontuacao = pontos[i];
                posicaoCampeao = i;
            }
        }

        System.out.println("--- PLACAR ---");

        for (int i = 0; i < 5; i++) {
            System.out.println(nomes[i] + " - " + pontos[i] + " pontos");
        }

        System.out.println("Campeao: " + nomes[posicaoCampeao]
                + " - " + maiorPontuacao + " pontos");

    }
}



