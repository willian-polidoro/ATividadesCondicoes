package MegaSena;

import java.util.Scanner;

public class Atividade09 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Informe quantos números você quer jogar:");
        int numeroJogo = sc.nextInt();

        int[] jogo = new int[numeroJogo];

        int[] resultado = {10, 20, 30, 40, 50, 60};

        for (int i = 0; i < numeroJogo; i++) {
            System.out.println("Informe o valor:");
            jogo[i] = sc.nextInt();
        }

        System.out.print("O jogo escolhido é: ");

        for (int i = 0; i < numeroJogo; i++) {
            System.out.print(jogo[i] + " ");
        }

        int acertos = 0;

        for (int i = 0; i < numeroJogo; i++) {

            for (int j = 0; j < 6; j++) {

                if (jogo[i] == resultado[j]) {
                    acertos++;

                    System.out.println("Quantidade de acertos: " + acertos);
                }
            }
        }


    }
}