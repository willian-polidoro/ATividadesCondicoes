package CarrinhoDeCompra;

import java.util.Scanner;

public class Atividade04 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        double[] preco = new double[6];

        double total = 0;{
        for (int i = 0; i < 6; i++) {
            System.out.println("Informe o preço do Produto " + (i + 1) + ":");
            preco[i] = sc.nextDouble();
            total += preco[i];
        }
            System.out.println("Valor total da compra é de : " + total + " reais");
        }
    }
}

