import java.util.Scanner;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[] gols = new int[8];

        int maiorNumroDeGols = 0;
        int jogadorComMaisGols = 0;

        for (int i = 0; i < 8; i++) {
            System.out.print("Jogador " + (i + 1) + ": ");
            gols[i] = sc.nextInt();
        }

        for (int i = 0; i < 8; i++) {
            if (gols[i] > maiorNumroDeGols) {
                maiorNumroDeGols = gols[i];
                jogadorComMaisGols = i + 1;
            }
        }


        System.out.println("Maior quantidade de gols: " + maiorNumroDeGols);
        System.out.println("Jogador que marcou mais gols: Jogador de nº :" + jogadorComMaisGols);

    }